package edu.uw.advjava.wilsonma;

import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;

@SelectClasses(SightingsUtilImplTests.class)
@Suite
class TestSuite {
}
